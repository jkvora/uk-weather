export interface urlOptions{
    metric:string
    location:string
}

