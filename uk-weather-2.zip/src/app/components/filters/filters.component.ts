import { Component, OnInit } from "@angular/core";
import { Subject } from "rxjs";
import { WealtherdataService } from "src/app/services/wealtherdata.service";
import { urlOptions } from "src/app/common/common.model";
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: "app-filters",
  templateUrl: "./filters.component.html",
  styleUrls: ["./filters.component.css"]
})
export class FiltersComponent implements OnInit {
  public countries:string[] = ["UK", "England", "Scotland", "Wales"];
  selectedMetric: string;
  metrics: string[] = ["Tmax (max temperature)", "Tmin (min temperature)", "Rainfall (mm)"];

   //UnSubscription  Object
   private unsubscribe = new Subject<void>();

  constructor(private weatherService:WealtherdataService) {}

  ngOnInit() {
    this.getData();
  }

  getData(){
    let options:urlOptions={
        metric:"Rainfall",
        location:"England"
    }
    this.weatherService.getWeatherData(options).pipe(takeUntil(this.unsubscribe)).subscribe(res => {
        console.log(res);
    });
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
